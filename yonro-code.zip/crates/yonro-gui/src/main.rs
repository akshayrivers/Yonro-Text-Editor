// `yonro-gui`: Tauri v2 desktop shell over `yonro-core` (`PLAN.md Phase 5.1`).
//
// Architecture contract (keeps a future pure-web build possible): ALL
// narrative reads go through the `#[tauri::command]`s below — the single
// adapter seam. The frontend (`ui/app.js`) renders; it never computes.
// A browser port would reimplement exactly these commands over WASM.

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Mutex;

use serde::Serialize;
use yonro_core::{Buffer, LoreBook, Manuscript};

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

struct AppState {
    workspace_dir: PathBuf,
    manuscript: Mutex<Manuscript>,
    lore: Mutex<LoreBook>,
    buffers: Mutex<HashMap<usize, GuiBuffer>>,
    next_buffer: Mutex<usize>,
}

/// One open document: rope buffer plus snapshot undo (v1: whole-text
/// snapshots capped at 100 — simple, correct; op-level undo is a later
/// optimization, not a correctness gap).
struct GuiBuffer {
    path: Option<PathBuf>,
    buffer: Buffer,
    undo: Vec<String>,
    redo: Vec<String>,
}

impl GuiBuffer {
    fn stats(&self) -> TextStats {
        let (words, graphemes, lines) = self.buffer.word_count_stats();
        TextStats {
            words,
            chars: graphemes,
            lines,
            reading_min: if words == 0 {
                0
            } else {
                words.div_ceil(200)
            },
            dirty: self.buffer.is_dirty(),
        }
    }
}

impl AppState {
    fn load(workspace_dir: PathBuf) -> Self {
        let manuscript = read_json::<Manuscript>(&workspace_dir.join(".yonro/manuscript.json"))
            .unwrap_or_else(|| Manuscript::new("Untitled"));
        let lore = read_json::<LoreBook>(&workspace_dir.join(".yonro/lore.json"))
            .unwrap_or_default();
        Self {
            workspace_dir,
            manuscript: Mutex::new(manuscript),
            lore: Mutex::new(lore),
            buffers: Mutex::new(HashMap::new()),
            next_buffer: Mutex::new(0),
        }
    }

    fn alloc_buffer(&self, buf: GuiBuffer) -> usize {
        let mut next = self.next_buffer.lock().unwrap_or_else(|e| e.into_inner());
        let id = *next;
        *next = next.saturating_add(1);
        self.buffers
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .insert(id, buf);
        id
    }
}

fn read_json<T: serde::de::DeserializeOwned>(path: &std::path::Path) -> Option<T> {
    serde_json::from_str(&std::fs::read_to_string(path).ok()?).ok()
}

// ---------------------------------------------------------------------------
// DTOs (plain shapes for the web UI — core types stay canonical in Rust)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize)]
struct TextStats {
    words: usize,
    chars: usize,
    lines: usize,
    reading_min: usize,
    dirty: bool,
}

#[derive(Debug, Clone, Serialize)]
struct OpenedDto {
    buffer_id: usize,
    path: Option<String>,
    text: String,
    stats: TextStats,
}

#[derive(Debug, Clone, Serialize)]
struct OutlineNodeDto {
    id: usize,
    kind: String,
    title: String,
    words: usize,
    target: usize,
    progress: f64,
    file: Option<String>,
    children: Vec<OutlineNodeDto>,
}

#[derive(Debug, Clone, Serialize)]
struct StatsDto {
    project: String,
    words: usize,
    target: usize,
    progress: f64,
    acts: usize,
    chapters: usize,
    scenes: usize,
    entities: usize,
}

#[derive(Debug, Clone, Serialize)]
struct EntityDto {
    id: usize,
    kind: String,
    name: String,
    aliases: Vec<String>,
    sheet: String,
    pov_scenes: Vec<String>,
}

fn kind_label(kind: yonro_core::NodeKind) -> &'static str {
    match kind {
        yonro_core::NodeKind::Project => "project",
        yonro_core::NodeKind::Act => "act",
        yonro_core::NodeKind::Chapter => "chapter",
        yonro_core::NodeKind::Scene => "scene",
    }
}

fn entity_kind_label(kind: yonro_core::EntityKind) -> &'static str {
    match kind {
        yonro_core::EntityKind::Character => "character",
        yonro_core::EntityKind::Place => "place",
        yonro_core::EntityKind::Faction => "faction",
        yonro_core::EntityKind::Item => "item",
        yonro_core::EntityKind::Lore => "lore",
    }
}

// ---------------------------------------------------------------------------
// Commands (the adapter seam — see module docs)
// ---------------------------------------------------------------------------

/// Full manuscript tree with per-node rollups.
#[tauri::command]
fn get_outline(state: tauri::State<'_, AppState>) -> OutlineNodeDto {
    let manuscript = state.manuscript.lock().unwrap_or_else(|e| e.into_inner());
    outline_dto(&manuscript)
}

fn outline_dto(manuscript: &Manuscript) -> OutlineNodeDto {
    fn build(manuscript: &Manuscript, id: usize) -> Option<OutlineNodeDto> {
        let node = manuscript.get(id)?;
        Some(OutlineNodeDto {
            id,
            kind: kind_label(node.kind).to_string(),
            title: node.title.clone(),
            words: manuscript.subtree_words(id),
            target: manuscript.subtree_target(id),
            progress: manuscript.progress(id),
            file: node
                .meta
                .as_ref()
                .and_then(|meta| meta.file.clone())
                .map(|path| path.to_string_lossy().to_string()),
            children: manuscript
                .children(id)
                .iter()
                .filter_map(|child| build(manuscript, child.id))
                .collect(),
        })
    }
    // Root always exists (fresh manuscripts start with a project node).
    build(manuscript, manuscript.root()).unwrap_or(OutlineNodeDto {
        id: 0,
        kind: "project".to_string(),
        title: manuscript.title().to_string(),
        words: 0,
        target: 0,
        progress: 0.0,
        file: None,
        children: Vec::new(),
    })
}

/// Project totals for the dashboard cards.
#[tauri::command]
fn get_stats(state: tauri::State<'_, AppState>) -> StatsDto {
    let manuscript = state.manuscript.lock().unwrap_or_else(|e| e.into_inner());
    let lore = state.lore.lock().unwrap_or_else(|e| e.into_inner());
    stats_dto(&manuscript, &lore)
}

fn stats_dto(manuscript: &Manuscript, lore: &LoreBook) -> StatsDto {
    let root = manuscript.root();
    let count = |kind: yonro_core::NodeKind| {
        fn walk(manuscript: &Manuscript, id: usize, kind: yonro_core::NodeKind, acc: &mut usize) {
            if let Some(node) = manuscript.get(id) {
                if node.kind == kind {
                    *acc = acc.saturating_add(1);
                }
                for child in manuscript.children(id) {
                    walk(manuscript, child.id, kind, acc);
                }
            }
        }
        let mut acc = 0;
        walk(manuscript, root, kind, &mut acc);
        acc
    };
    StatsDto {
        project: manuscript.title().to_string(),
        words: manuscript.subtree_words(root),
        target: manuscript.subtree_target(root),
        progress: manuscript.progress(root),
        acts: count(yonro_core::NodeKind::Act),
        chapters: count(yonro_core::NodeKind::Chapter),
        scenes: count(yonro_core::NodeKind::Scene),
        entities: lore.live_count(),
    }
}

/// Every lore entity with POV backlinks.
#[tauri::command]
fn get_lore(state: tauri::State<'_, AppState>) -> Vec<EntityDto> {
    let manuscript = state.manuscript.lock().unwrap_or_else(|e| e.into_inner());
    let lore = state.lore.lock().unwrap_or_else(|e| e.into_inner());
    lore_dtos(&manuscript, &lore)
}

fn lore_dtos(manuscript: &Manuscript, lore: &LoreBook) -> Vec<EntityDto> {
    let mut pov_scenes: Vec<(String, String)> = Vec::new();
    for act in manuscript.children(manuscript.root()) {
        for chapter in manuscript.children(act.id) {
            for scene in manuscript.children(chapter.id) {
                if let Some(meta) = scene.meta.as_ref() {
                    if !meta.pov.trim().is_empty() {
                        pov_scenes.push((meta.pov.clone(), scene.title.clone()));
                    }
                }
            }
        }
    }
    let mut entities: Vec<EntityDto> = Vec::new();
    // NOTE: `LoreBook` has no public iterator yet; resolve via prefix "".
    for entity in lore.find_by_prefix("") {
        let mut scenes: Vec<String> = pov_scenes
            .iter()
            .filter(|(pov, _)| {
                pov.eq_ignore_ascii_case(&entity.name)
                    || entity
                        .aliases
                        .iter()
                        .any(|alias| pov.eq_ignore_ascii_case(alias))
            })
            .map(|(_, title)| title.clone())
            .collect();
        scenes.sort();
        scenes.dedup();
        entities.push(EntityDto {
            id: entity.id,
            kind: entity_kind_label(entity.kind).to_string(),
            name: entity.name.clone(),
            aliases: entity.aliases.clone(),
            sheet: entity.sheet.clone(),
            pov_scenes: scenes,
        });
    }
    entities.sort_by_key(|a| a.name.to_lowercase());
    entities
}

/// Workspace directory the GUI was opened in (for the header).
#[tauri::command]
fn get_workspace_dir(state: tauri::State<'_, AppState>) -> String {
    state.workspace_dir.to_string_lossy().to_string()
}

// ---------------------------------------------------------------------------
// Editing (whole-text sync; single user, sequential invokes — no races)
// ---------------------------------------------------------------------------

fn with_buffer<T>(
    state: &tauri::State<'_, AppState>,
    buffer_id: usize,
    f: impl FnOnce(&mut GuiBuffer) -> T,
) -> Result<T, String> {
    let mut buffers = state.buffers.lock().unwrap_or_else(|e| e.into_inner());
    match buffers.get_mut(&buffer_id) {
        Some(buf) => Ok(f(buf)),
        None => Err(format!("unknown buffer {buffer_id}")),
    }
}

/// Open a file (or an empty draft with `path: null`) for editing.
#[tauri::command]
fn open_file(
    state: tauri::State<'_, AppState>,
    path: Option<String>,
) -> Result<OpenedDto, String> {
    let buffer = match &path {
        Some(path) => {
            Buffer::load(path).map_err(|err| format!("cannot open {path}: {err}"))?
        }
        None => Buffer::default(),
    };
    let gui = GuiBuffer {
        path: path.clone().map(PathBuf::from),
        buffer,
        undo: Vec::new(),
        redo: Vec::new(),
    };
    let dto = OpenedDto {
        buffer_id: 0, // filled in below
        path,
        text: gui.buffer.text(),
        stats: gui.stats(),
    };
    let buffer_id = state.alloc_buffer(gui);
    Ok(OpenedDto {
        buffer_id,
        ..dto
    })
}

/// Replace a buffer's whole text (snapshot undo, capped at 100).
#[tauri::command]
fn set_text(
    state: tauri::State<'_, AppState>,
    buffer_id: usize,
    text: String,
) -> Result<TextStats, String> {
    with_buffer(&state, buffer_id, |buf| {
        let current = buf.buffer.text();
        if current != text {
            buf.undo.push(current);
            if buf.undo.len() > 100 {
                buf.undo.remove(0);
            }
            buf.redo.clear();
            buf.buffer.set_text(&text);
        }
        buf.stats()
    })
}

/// Save a buffer. No path anywhere → deterministic `untitled-<id>.md` in
/// the workspace (native Save-As dialogs need an extra plugin; the message
/// tells the user the exact file).
#[tauri::command]
fn save_file(
    state: tauri::State<'_, AppState>,
    buffer_id: usize,
    path: Option<String>,
) -> Result<String, String> {
    let stored = {
        let buffers = state.buffers.lock().unwrap_or_else(|e| e.into_inner());
        buffers
            .get(&buffer_id)
            .and_then(|buf| buf.path.clone())
            .map(|path| path.to_string_lossy().to_string())
    };
    let target = path.or(stored).unwrap_or_else(|| {
        let mut n = buffer_id;
        loop {
            let candidate = state.workspace_dir.join(format!("untitled-{n}.md"));
            if !candidate.exists() {
                break candidate.to_string_lossy().to_string();
            }
            n = n.saturating_add(1);
        }
    });
    with_buffer(&state, buffer_id, |buf| {
        buf.buffer
            .save_as(&target)
            .map_err(|err| format!("cannot save {target}: {err}"))?;
        buf.path = Some(PathBuf::from(&target));
        Ok(target.clone())
    })?
}

/// Drop a buffer from the session.
#[tauri::command]
fn close_buffer(state: tauri::State<'_, AppState>, buffer_id: usize) -> Result<(), String> {
    let mut buffers = state.buffers.lock().unwrap_or_else(|e| e.into_inner());
    buffers
        .remove(&buffer_id)
        .map(|_| ())
        .ok_or_else(|| format!("unknown buffer {buffer_id}"))
}

/// Undo / redo via whole-text snapshots.
#[tauri::command]
fn undo_buffer(
    state: tauri::State<'_, AppState>,
    buffer_id: usize,
) -> Result<EditDto, String> {
    with_buffer(&state, buffer_id, |buf| {
        if let Some(prev) = buf.undo.pop() {
            buf.redo.push(buf.buffer.text());
            buf.buffer.set_text(&prev);
        }
        EditDto {
            text: buf.buffer.text(),
            stats: buf.stats(),
        }
    })
}

#[tauri::command]
fn redo_buffer(
    state: tauri::State<'_, AppState>,
    buffer_id: usize,
) -> Result<EditDto, String> {
    with_buffer(&state, buffer_id, |buf| {
        if let Some(next) = buf.redo.pop() {
            buf.undo.push(buf.buffer.text());
            buf.buffer.set_text(&next);
        }
        EditDto {
            text: buf.buffer.text(),
            stats: buf.stats(),
        }
    })
}

#[derive(Debug, Clone, Serialize)]
struct EditDto {
    text: String,
    stats: TextStats,
}

// ---------------------------------------------------------------------------
// Graph + timeline (computed in core, rendered in JS)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize)]
struct GraphNodeDto {
    id: usize,
    label: String,
    kind: String,
}

#[derive(Debug, Clone, Serialize)]
struct GraphEdgeDto {
    a: usize,
    b: usize,
    shared: usize,
    mentions: usize,
    weight: usize,
    kinds: Vec<String>,
}

#[derive(Debug, Clone, Serialize)]
struct GraphDto {
    nodes: Vec<GraphNodeDto>,
    edges: Vec<GraphEdgeDto>,
}

/// Relationship graph: scene texts come from open buffers (path-matched to
/// scene files) so mentions in *unsaved* drafts still link.
#[tauri::command]
fn get_graph(state: tauri::State<'_, AppState>) -> GraphDto {
    use std::collections::BTreeMap;
    let manuscript = state.manuscript.lock().unwrap_or_else(|e| e.into_inner());
    let lore = state.lore.lock().unwrap_or_else(|e| e.into_inner());
    let buffers = state.buffers.lock().unwrap_or_else(|e| e.into_inner());
    // Scene file → draft text (open buffers win over disk).
    let mut by_file: BTreeMap<String, String> = BTreeMap::new();
    for buf in buffers.values() {
        if let Some(path) = buf.path.as_ref() {
            by_file.insert(path.to_string_lossy().to_string(), buf.buffer.text());
        }
    }
    let mut scene_texts: BTreeMap<usize, String> = BTreeMap::new();
    let root = manuscript.root();
    let acts: Vec<usize> = manuscript.children(root).iter().map(|n| n.id).collect();
    for act in acts {
        for chapter in manuscript.children(act).iter().map(|n| n.id) {
            for scene in manuscript.children(chapter) {
                let file = scene
                    .meta
                    .as_ref()
                    .and_then(|meta| meta.file.clone())
                    .map(|path| path.to_string_lossy().to_string());
                if let Some(file) = file {
                    let text = by_file.get(&file).cloned().unwrap_or_else(|| {
                        std::fs::read_to_string(&file).unwrap_or_default()
                    });
                    scene_texts.insert(scene.id, text);
                }
            }
        }
    }
    graph_dto(&manuscript, &lore, &scene_texts)
}

fn graph_dto(
    manuscript: &Manuscript,
    lore: &LoreBook,
    scene_texts: &std::collections::BTreeMap<usize, String>,
) -> GraphDto {
    let graph = yonro_core::Graph::build(manuscript, lore, scene_texts);
    let nodes = graph
        .nodes
        .iter()
        .filter_map(|id| lore.get(*id))
        .map(|entity| GraphNodeDto {
            id: entity.id,
            label: entity.name.clone(),
            kind: entity_kind_label(entity.kind).to_string(),
        })
        .collect();
    let edges = graph
        .edges
        .iter()
        .map(|edge| GraphEdgeDto {
            a: edge.a,
            b: edge.b,
            shared: edge.shared_scenes,
            mentions: edge.mention_scenes,
            weight: edge.weight(),
            kinds: edge
                .kinds()
                .iter()
                .map(|kind| {
                    match kind {
                        yonro_core::EdgeKind::Cooccurrence => "shared scene",
                        yonro_core::EdgeKind::Mention => "mention",
                    }
                    .to_string()
                })
                .collect(),
        })
        .collect();
    GraphDto { nodes, edges }
}

#[derive(Debug, Clone, Serialize)]
struct TimelineEntryDto {
    index: usize,
    scene: usize,
    title: String,
    chapter: String,
    pov: String,
    setting: String,
    story_date: String,
    words: usize,
}

#[derive(Debug, Clone, Serialize)]
struct ContinuityNoteDto {
    message: String,
    scenes: Vec<usize>,
}

#[derive(Debug, Clone, Serialize)]
struct TimelineDto {
    entries: Vec<TimelineEntryDto>,
    notes: Vec<ContinuityNoteDto>,
}

/// Outline-ordered timeline plus continuity notes.
#[tauri::command]
fn get_timeline(state: tauri::State<'_, AppState>) -> TimelineDto {
    let manuscript = state.manuscript.lock().unwrap_or_else(|e| e.into_inner());
    timeline_dto(&manuscript)
}

fn timeline_dto(manuscript: &Manuscript) -> TimelineDto {
    let timeline = yonro_core::Timeline::build(manuscript);
    TimelineDto {
        entries: timeline
            .entries
            .iter()
            .map(|entry| TimelineEntryDto {
                index: entry.index,
                scene: entry.scene,
                title: entry.title.clone(),
                chapter: entry.chapter.clone(),
                pov: entry.pov.clone(),
                setting: entry.setting.clone(),
                story_date: entry.story_date.clone(),
                words: entry.words,
            })
            .collect(),
        notes: timeline
            .continuity_notes()
            .iter()
            .map(|note| ContinuityNoteDto {
                message: note.message.clone(),
                scenes: note.scenes.clone(),
            })
            .collect(),
    }
}

fn main() {
    let workspace_dir = std::env::args()
        .nth(1)
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."))
        });
    tauri::Builder::default()
        .manage(AppState::load(workspace_dir))
        .invoke_handler(tauri::generate_handler![
            get_outline,
            get_stats,
            get_lore,
            get_workspace_dir,
            open_file,
            set_text,
            save_file,
            close_buffer,
            undo_buffer,
            redo_buffer,
            get_graph,
            get_timeline
        ])
        .run(tauri::generate_context!())
        .expect("error running yonro gui");
}

#[cfg(test)]
mod tests {
    use super::*;

    fn seed_workspace() -> PathBuf {
        let dir = std::env::temp_dir().join(format!("yonro-gui-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join(".yonro")).unwrap();
        let manuscript = Manuscript::new("Probe");
        std::fs::write(
            dir.join(".yonro/manuscript.json"),
            serde_json::to_string(&manuscript).unwrap(),
        )
        .unwrap();
        std::fs::write(dir.join(".yonro/lore.json"), serde_json::to_string(&LoreBook::default()).unwrap())
            .unwrap();
        dir
    }

    #[test]
    fn loads_workspace_and_reports_empty_stats() {
        let dir = seed_workspace();
        let state = AppState::load(dir.clone());
        assert_eq!(state.workspace_dir, dir);
        assert_eq!(state.manuscript.lock().unwrap().title(), "Probe");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn missing_workspace_falls_back_to_untitled() {
        let dir = std::env::temp_dir().join(format!("yonro-gui-missing-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let state = AppState::load(dir);
        assert_eq!(state.manuscript.lock().unwrap().title(), "Untitled");
    }

    fn seed_story() -> (Manuscript, LoreBook) {
        use yonro_core::{EntityKind, SceneMeta};
        let mut ms = Manuscript::new("Probe");
        let act = ms.add_act("Act I").unwrap();
        let ch = ms.add_chapter(act, "Chapter 1").unwrap();
        let sc = ms.add_scene(ch, "The gate").unwrap();
        ms.set_meta(
            sc,
            SceneMeta {
                pov: "Mara".to_string(),
                target_words: 1000,
                current_words: 250,
                ..SceneMeta::default()
            },
        )
        .unwrap();
        let mut lore = LoreBook::new();
        lore.add(EntityKind::Character, "Mara").unwrap();
        (ms, lore)
    }

    #[test]
    fn outline_dto_mirrors_tree_with_rollups() {
        let (ms, _) = seed_story();
        let dto = outline_dto(&ms);
        assert_eq!(dto.title, "Probe");
        assert_eq!(dto.words, 250);
        assert_eq!(dto.target, 1000);
        assert_eq!(dto.children.len(), 1);
        let scene = &dto.children[0].children[0].children[0];
        assert_eq!(scene.title, "The gate");
        assert_eq!(scene.kind, "scene");
    }

    #[test]
    fn stats_dto_counts_levels() {
        let (ms, lore) = seed_story();
        let stats = stats_dto(&ms, &lore);
        assert_eq!(stats.project, "Probe");
        assert_eq!((stats.acts, stats.chapters, stats.scenes), (1, 1, 1));
        assert_eq!(stats.entities, 1);
        assert!((stats.progress - 0.25).abs() < f64::EPSILON);
    }

    #[test]
    fn lore_dtos_carry_pov_backlinks_sorted() {
        let (ms, lore) = seed_story();
        let dtos = lore_dtos(&ms, &lore);
        assert_eq!(dtos.len(), 1);
        assert_eq!(dtos[0].name, "Mara");
        assert_eq!(dtos[0].pov_scenes, vec!["The gate".to_string()]);
    }

    #[test]
    fn graph_dto_links_mention_edges() {
        use std::collections::BTreeMap;
        use yonro_core::EntityKind;
        let (ms, mut lore) = seed_story();
        lore.add(EntityKind::Character, "Joren").unwrap();
        let scene = ms.children(ms.children(ms.root())[0].id)[0].id;
        let scene = ms.children(scene)[0].id;
        let mut texts = BTreeMap::new();
        texts.insert(scene, "Mara waved at @Joren.".to_string());
        let dto = graph_dto(&ms, &lore, &texts);
        assert_eq!(dto.nodes.len(), 2);
        assert_eq!(dto.edges.len(), 1);
        assert_eq!(dto.edges[0].mentions, 1);
        assert!(dto.edges[0].kinds.iter().any(|k| k == "mention"));
    }

    #[test]
    fn timeline_dto_orders_entries_and_notes() {
        let (ms, _) = seed_story();
        let dto = timeline_dto(&ms);
        assert_eq!(dto.entries.len(), 1);
        assert_eq!(dto.entries[0].title, "The gate");
        // Seed scene has a POV but no setting → exactly one note.
        assert_eq!(dto.notes.len(), 1);
        assert!(dto.notes[0].message.contains("no setting"));
    }

    #[test]
    fn corrupt_workspace_falls_back_safely() {        let dir = std::env::temp_dir().join(format!("yonro-gui-corrupt-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join(".yonro")).unwrap();
        std::fs::write(dir.join(".yonro/manuscript.json"), "not json{{").unwrap();
        std::fs::write(dir.join(".yonro/lore.json"), "{}").unwrap();
        let state = AppState::load(dir.clone());
        assert_eq!(state.manuscript.lock().unwrap().title(), "Untitled");
        let _ = std::fs::remove_dir_all(&dir);
    }
}
